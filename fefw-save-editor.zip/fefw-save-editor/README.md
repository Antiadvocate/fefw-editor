# Fortune's Weave — save editor

Reads and edits the save slots that **Eden / eglantine** write for
*Fire Emblem: Fortune's Weave* (title id `04007EF01F8AE000`).

Unofficial, reverse-engineered tool. Back up your save before using it.

## What it can edit

| Tab | Field | Notes |
|---|---|---|
| Unit | Level, EXP, Max HP | straightforward |
| Unit | HP, Str, Mag, Dex, Spd, Lck, Def, Res, Cha | the game's own stat order; the HP value here is **current** HP |
| Unit | Class | stored as a hash of the game's job id; movement/weapons/class skills are derived by the game and are not rewritten |
| Aptitude | skill experience per skill family | one row per skill the unit owns; a letter writes the start of that grade |
| Items | items in a unit's inventory | swaps the id, keeps the uses bytes |
| Convoy | shared storage | append / replace / clear rows |
| Money | gold | search for the amount the game shows, then set it |

Skills: Swords, Lances, Axes, Bows, Fists, Black Magic, White Magic, Infantry,
Riding, Heavy Armor, Flying, Authority.

Grade ladder (thresholds used when you pick a letter): E 0, E+ 40, D 100, D+ 180,
C 300, C+ 460, B 680, B+ 960, A 1320, A+ 1760, S 2520, S+ 3600.

## Requirements

* Python 3.10+ (tested with 3.11)
* `pip install -r requirements.txt` (only `zstandard`)

Then double-click **FEFW Save Editor.bat**, or run `python editor.py`.

## Using it

* It opens **one slot file at a time** from
  `%APPDATA%\eden\nand\user\save\<play-uid>\<account>\04007EF01F8AE000\000\`.
  The dropdown lists every slot with its unit count and timestamp; whatever is
  selected is what you are editing, and **Save file** writes only that file.
* Mid-chapter the game resumes from a `Chapter_*` slot, not `Auto`. The Aptitude
  tab has *write these grades into every slot file* for exactly that.
* A unit is stored as **several copies** in a file. The editor shows one row per
  unit and writes every copy; if the copies disagree it says so, because that is
  the usual reason an edit "doesn't show up" in game.
* Close the game before writing. The first write next to a slot leaves a `.bak`.

## Known limits

* Only the class **id** is written. The game derives movement, usable weapons,
  class skills and max HP from the class — those are not rewritten here.
* A unit only has entries for the skills it owns. Missing ones show `E` in game
  and cannot be added (the list is fixed-size inside the record).
* Gold needs the amount the game currently shows.
* Renown ("Honor" in the data) and the convoy material bag are not editable.

## Data files

* `unit_ids.json` — person id hash → name (from `Person.bin` + `Person.msbt`)
* `item_ids.json` — item id hash → Japanese + English name
* `job_ids.json` — class id hash → Japanese + English name

They are generated from the game's own files; a different game version may need
regenerating, otherwise new ids show as `unknown … <hash>`.

## Licence

No licence attached — do what you like with it, but it is provided as-is with no
warranty, and editing saves can corrupt them. Keep your own backups.
